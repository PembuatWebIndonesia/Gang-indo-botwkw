import { CommandInfo } from '../types';

export const COMMANDS_DATA: CommandInfo[] = [
  // --- KTP & Sistem Warga ---
  { name: 'setup-ktp', description: 'Menyiapkan loket pembuatan KTP Virtual di channel saat ini.', category: 'KTP & Sistem Warga', usage: '/setup-ktp', exampleResponse: 'Loket KTP Virtual sukses dikirim ke channel #loket-ktp!' },
  { name: 'setup-gachanasib', description: 'Menyiapkan panel gacha role nasib otomatis di channel saat ini.', category: 'KTP & Sistem Warga', usage: '/setup-gachanasib', exampleResponse: 'Sistem Gacha Nasib berhasil dipasang di channel #gacha-role!' },
  { name: 'my-ktp', description: 'Menampilkan KTP Virtual milk Anda atau user lain.', category: 'KTP & Sistem Warga', usage: '/my-ktp [user]', exampleResponse: 'Menampilkan Kartu Tanda Penduduk milik @novirahmiati.' },
  { name: 'edit-ktp', description: 'Mengubah deskripsi atau status pada KTP.', category: 'KTP & Sistem Warga', usage: '/edit-ktp [bio]', exampleResponse: 'Bio KTP telah diperbarui menjadi "Bekerja di Google".' },
  { name: 'hapus-ktp', description: 'Menghapus data KTP untuk buat ulang dari awal.', category: 'KTP & Sistem Warga', usage: '/hapus-ktp', exampleResponse: 'Data KTP Anda telah dihapus secara permanen.' },

  // --- AI & Otomatisasi ---
  { name: 'tanya-ai', description: 'Bertanya apa saja ke kecerdasan buatan Gemini AI.', category: 'AI & Otomatisasi', usage: '/tanya-ai [pertanyaan]', exampleResponse: 'Menurut analisis saya, server Gang Discord Indonesia memiliki potensi...' },
  { name: 'analisis-server', description: 'Menganalisis status keaktifan server secara cerdas dengan Gemini AI.', category: 'AI & Otomatisasi', usage: '/analisis-server', exampleResponse: 'Skor keaktifan 98/100. Rekomendasi: Adakan event Voice Chat.' },
  { name: 'ai-gambar', description: 'Membuat gambar dari teks yang kamu ketik menggunakan Gemini Vision.', category: 'AI & Otomatisasi', usage: '/ai-gambar [deskripsi]', exampleResponse: '🎨 AI telah melukis gambar "Kucing garong main gitar" untukmu!' },
  { name: 'ai-ringkas', description: 'Meringkas ratusan pesan chat menjadi poin penting.', category: 'AI & Otomatisasi', usage: '/ai-ringkas [jumlah]', exampleResponse: '📝 Kesimpulan chat: Warga setuju mengubah rules ke-5.' },
  { name: 'ai-translate', description: 'Terjemahkan teks ke berbagai bahasa (Otomatis deteksi bahasa).', category: 'AI & Otomatisasi', usage: '/ai-translate [teks]', exampleResponse: 'Menerjemahkan teks dari Jawa ke Indonesia secara akurat.' },
  { name: 'ai-cari-koding', description: 'Cari solusi error programming atau bikin skrip code Python/JS.', category: 'AI & Otomatisasi', usage: '/ai-cari-koding [bahasa] [masalah]', exampleResponse: '👨‍💻 Ini skrip Python untuk scrape data website otomatis...' },
  { name: 'ai-roasting', description: 'Minta AI roasting profil Discord kamu.', category: 'AI & Otomatisasi', usage: '/ai-roasting [user]', exampleResponse: '🔥 Profil lu avatarnya anime mulu, mending mandi gih bau bawang.' },
  { name: 'ai-ideas', description: 'Minta AI menggenerate ide event server yang menarik.', category: 'AI & Otomatisasi', usage: '/ai-ideas', exampleResponse: 'Ide event: Lomba menggambar logo server dengan bot AI.' },
  { name: 'ai-fact', description: 'Dapatkan fakta unik random untuk menghangatkan suasana.', category: 'AI & Otomatisasi', usage: '/ai-fact', exampleResponse: 'Tahukah kamu? Jantung udang terletak di kepalanya.' },
  { name: 'ai-rules-gen', description: 'Generate rules server profesional otomatis dengan AI.', category: 'AI & Otomatisasi', usage: '/ai-rules-gen [tipe_server]', exampleResponse: 'Menggenerate 10 Rules untuk server Komunitas Gaming.' },

  // --- Moderasi Core ---
  { name: 'ban', description: 'Memblokir anggota dari server secara permanen.', category: 'Moderasi Core', usage: '/ban [user] [alasan]', exampleResponse: 'Anggota @bams sukses diblokir permanen.', permissions: ['Ban Members'] },
  { name: 'unban', description: 'Membuka blokir mantan anggota server.', category: 'Moderasi Core', usage: '/unban [user_id]', exampleResponse: 'Pemblokiran untuk ID 123456789 telah dicabut.', permissions: ['Ban Members'] },
  { name: 'kick', description: 'Mengeluarkan anggota dari server.', category: 'Moderasi Core', usage: '/kick [user] [alasan]', exampleResponse: 'Anggota @kikim sukses dikeluarkan dari server.', permissions: ['Kick Members'] },
  { name: 'mute', description: 'Membisukan suara/ketikan anggota di server.', category: 'Moderasi Core', usage: '/mute [user] [durasi] [alasan]', exampleResponse: 'Anggota @tole sukses dimute selama 1 jam.', permissions: ['Moderate Members'] },
  { name: 'unmute', description: 'Mengembalikan suara/hak ketik anggota.', category: 'Moderasi Core', usage: '/unmute [user]', exampleResponse: 'Hukuman mute untuk @tole telah dicabut.', permissions: ['Moderate Members'] },
  { name: 'warn', description: 'Memberikan peringatan formal kepada anggota.', category: 'Moderasi Core', usage: '/warn [user] [alasan]', exampleResponse: 'Peringatan ke-1 dikirimkan ke @tole. Alasan: Spam.', permissions: ['Manage Messages'] },
  { name: 'warn-list', description: 'Melihat histori peringatan tertulis anggota.', category: 'Moderasi Core', usage: '/warn-list [user]', exampleResponse: 'Histori @tole: 1 Warn (Capslock berlebihan).' },
  { name: 'warn-clear', description: 'Menghapus seluruh histori peringatan anggota.', category: 'Moderasi Core', usage: '/warn-clear [user]', exampleResponse: 'Seluruh peringatan untuk @tole telah dibersihkan.', permissions: ['Manage Messages', 'Administrator'] },
  { name: 'clear', description: 'Menghapus pesan dalam jumlah banyak di channel.', category: 'Moderasi Core', usage: '/clear [jumlah]', exampleResponse: 'Sukses menyapu bersih 50 pesan kotor!', permissions: ['Manage Messages'] },
  { name: 'lock', description: 'Mengunci channel saat ini agar tidak bisa diketik.', category: 'Moderasi Core', usage: '/lock [alasan]', exampleResponse: 'Channel #general telah dikunci sementara.', permissions: ['Manage Channels'] },
  { name: 'unlock', description: 'Membuka kunci channel agar bisa diketik kembali.', category: 'Moderasi Core', usage: '/unlock', exampleResponse: 'Lock dicabut. Channel #general siap digunakan.', permissions: ['Manage Channels'] },
  { name: 'slowmode', description: 'Mengatur durasi jeda pengiriman pesan di channel.', category: 'Moderasi Core', usage: '/slowmode [detik]', exampleResponse: 'Slowmode dipasang: 5 detik jeda per pesan.', permissions: ['Manage Channels'] },
  { name: 'timeout', description: 'Mengistirahatkan anggota dari obrolan secara otomatis (Discord Timeout).', category: 'Moderasi Core', usage: '/timeout [user] [menit]', exampleResponse: 'Anggota @rusdi ditaruh di ruang timeout 15 menit.', permissions: ['Moderate Members'] },
  { name: 'untimeout', description: 'Melepaskan status timeout dari anggota.', category: 'Moderasi Core', usage: '/untimeout [user]', exampleResponse: 'Status timeout @rusdi telah dilepaskan.', permissions: ['Moderate Members'] },
  { name: 'purge-user', description: 'Menghapus pesan dari satu user spesifik di channel ini.', category: 'Moderasi Core', usage: '/purge-user [user] [jumlah]', exampleResponse: 'Sukses menghapus 15 pesan terakhir dari @spammer.', permissions: ['Manage Messages'] },
  { name: 'purge-links', description: 'Menghapus semua link/url di channel dalam 100 pesan terakhir.', category: 'Moderasi Core', usage: '/purge-links', exampleResponse: 'Berhasil membersihkan 12 pesan berisi tautan.', permissions: ['Manage Messages'] },
  { name: 'purge-bots', description: 'Menghapus riwayat pesan bot di channel ini.', category: 'Moderasi Core', usage: '/purge-bots', exampleResponse: '50 pesan dari bot sukses dibersihkan.', permissions: ['Manage Messages'] },

  // --- Keamanan & Automod ---
  { name: 'anti-raid', description: 'Tombol darurat! Kunci seluruh channel & batasi akun baru masuk.', category: 'Keamanan & Automod', usage: '/anti-raid [durasi]', exampleResponse: '🚨 Mode Anti-Raid Aktif! Server lock down 2 Jam.', permissions: ['Administrator'] },
  { name: 'anti-spam', description: 'Konfigurasi deteksi spam ketikan cepat.', category: 'Keamanan & Automod', usage: '/anti-spam [on/off]', exampleResponse: 'Deteksi anti-spam tingkat ketat telah dihidupkan.', permissions: ['Administrator'] },
  { name: 'anti-link', description: 'Blokir pengiriman link server lain atau pishing.', category: 'Keamanan & Automod', usage: '/anti-link [on/off]', exampleResponse: 'Anti-link dihidupkan. Anggota biasa dilarang kirim link.', permissions: ['Administrator'] },
  { name: 'anti-nsfw', description: 'Mendeteksi dan menghapus gambar terlarang otomatis.', category: 'Keamanan & Automod', usage: '/anti-nsfw [on/off]', exampleResponse: 'Filter gambar tidak senonoh (NSFW) telah aktif.' },
  { name: 'anti-caps', description: 'Memberikan teguran bagi yang chat menggunakan huruf kapital semua.', category: 'Keamanan & Automod', usage: '/anti-caps [on/off]', exampleResponse: 'Deteksi huruf kapital telah aktif.' },
  { name: 'blacklist-word', description: 'Menambah kata makian ke dalam daftar hitam sensor.', category: 'Keamanan & Automod', usage: '/blacklist-word [kata]', exampleResponse: 'Kata "bodoh" telah dimasukkan ke daftar hitam.' },
  { name: 'whitelist-word', description: 'Mencabut kata dari daftar blacklist sensor.', category: 'Keamanan & Automod', usage: '/whitelist-word [kata]', exampleResponse: 'Kata "bodoh" dihapus dari daftar hitam.' },
  { name: 'verify-setup', description: 'Memasang panel verifikasi CAPTCHA / tombol untuk warga baru.', category: 'Keamanan & Automod', usage: '/verify-setup', exampleResponse: 'Panel verifikasi sukses dibuat di channel ini.' },
  { name: 'bypass-role', description: 'Menetapkan role kebal (admin/mod) dari sistem Automod.', category: 'Keamanan & Automod', usage: '/bypass-role [role]', exampleResponse: 'Role @Moderator sekarang kebal dari sistem Automod.' },
  { name: 'check-alt', description: 'Menganalisis akun mencurigakan (clone/pembuat rusuh) di server.', category: 'Keamanan & Automod', usage: '/check-alt', exampleResponse: 'Terdeteksi 3 akun yang baru dibuat kurang dari 24 jam.' },

  // --- Manajemen Server ---
  { name: 'set-welcome', description: 'Mengatur channel ucapan selamat datang untuk member baru.', category: 'Manajemen Server', usage: '/set-welcome [channel]', exampleResponse: 'Channel #welcome berhasil diset sebagai gerbang masuk.' },
  { name: 'set-leave', description: 'Mengatur channel pesan keluar saat ada member yang minggat.', category: 'Manajemen Server', usage: '/set-leave [channel]', exampleResponse: 'Channel #goodbye berhasil diset.' },
  { name: 'auto-role', description: 'Memberi role otomatis untuk siapa saja yang baru join server.', category: 'Manajemen Server', usage: '/auto-role [role]', exampleResponse: 'Anggota baru akan otomatis mendapat role @Warga.' },
  { name: 'reaction-role', description: 'Membuat menu klik emoji dapat role secara otomatis.', category: 'Manajemen Server', usage: '/reaction-role [pesan_id] [emoji] [role]', exampleResponse: 'Reaction Role sukses dipasang! Klik emoji 🎮 untuk @Gamer.' },
  { name: 'embed-maker', description: 'Membuat pesan berkotak indah (Embed) kustomisasi warna dan gambar.', category: 'Manajemen Server', usage: '/embed-maker', exampleResponse: 'Panel Embed Editor terbuka...' },
  { name: 'announce', description: 'Bikin pengumuman pintar dengan Embed terpisah.', category: 'Manajemen Server', usage: '/announce [channel] [pesan]', exampleResponse: '📢 Pengumuman rapi berhasil dikirim ke #general-chat!' },
  { name: 'poll', description: 'Membuat pemungutan suara (voting) reaksi cepat.', category: 'Manajemen Server', usage: '/poll [teks]', exampleResponse: 'Polling dimulai: "Makan Bakso?" Berikan reaksi 👍 atau 👎!' },
  { name: 'channel-create', description: 'Membuat text / voice channel baru dengan cepat.', category: 'Manajemen Server', usage: '/channel-create [tipe] [nama]', exampleResponse: 'Channel suara 🔊Tongkrongan sukses dibuat.' },
  { name: 'channel-delete', description: 'Menghapus channel tertentu.', category: 'Manajemen Server', usage: '/channel-delete [channel]', exampleResponse: 'Channel #test-spam telah dihapus secara permanen.' },
  { name: 'nuke', description: 'Membersihkan 100% isi channel dengan cara re-create channel.', category: 'Manajemen Server', usage: '/nuke', exampleResponse: '☢️ BOOM! Channel dire-create bersih seperti sedia kala.' },
  { name: 'backup-server', description: 'Buat file backup kategori, channel, dan role server ke database.', category: 'Manajemen Server', usage: '/backup-server', exampleResponse: '💾 Backup struktural sukses disimpan dengan ID: BAK-98124' },
  { name: 'restore-server', description: 'Mengembalikan format server yang rusak (HACKED) menggunakan file backup.', category: 'Manajemen Server', usage: '/restore-server [id_backup]', exampleResponse: 'Memulai proses pemulihan channel dari backup BAK-98124...' },
  { name: 'role-give', description: 'Memberikan pangkat (role) spesifik ke seorang member.', category: 'Manajemen Server', usage: '/role-give [user] [role]', exampleResponse: '🛡️ Role "VIP Community" diberikan kepada @kicaumania.' },
  { name: 'role-remove', description: 'Mencopot pangkat (role) dari seseorang dengan paksa.', category: 'Manajemen Server', usage: '/role-remove [user] [role]', exampleResponse: '❌ Role "VIP Community" dicopot dari @scammer.' },
  { name: 'role-give-all', description: 'Memberikan sebuah role ke SELURUH member server.', category: 'Manajemen Server', usage: '/role-give-all [role]', exampleResponse: 'Role @EventParticipant dipasang ke 253 member.' },

  // --- Sistem Tiket Lanjutan ---
  { name: 'ticket-setup', description: 'Membuat panel tiket di channel spesifik.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-setup', exampleResponse: 'Panel tiket Support/Laporan berhasil dipasang.' },
  { name: 'ticket-close', description: 'Menutup tiket yang sudah selesai ditangani.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-close [alasan]', exampleResponse: 'Tiket akan ditutup dalam 5 detik.' },
  { name: 'ticket-add', description: 'Menambah user/admin lain ke dalam tiket privat ini.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-add [user]', exampleResponse: '@Manager telah dimasukkan ke dalam tiket-001.' },
  { name: 'ticket-remove', description: 'Mengeluarkan user dari tiket privat ini.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-remove [user]', exampleResponse: '@Perusuh telah di-kick dari tiket.' },
  { name: 'ticket-claim', description: 'Admin mengklain tiket ini agar tidak diambil admin lain.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-claim', exampleResponse: 'Tiket berhasil diklaim. Staff penanggung jawab: @Rahmat.' },
  { name: 'ticket-transcript', description: 'Mengekspor seluruh isi obrolan tiket ke dalam file web HTML.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-transcript', exampleResponse: 'Transkrip tiket berhasil digenerate: [File Terlampir]' },
  { name: 'ticket-category', description: 'Menambahkan kategori topik pada panel tiket (Misal: Report, Donate).', category: 'Sistem Tiket Lanjutan', usage: '/ticket-category [nama]', exampleResponse: 'Kategori tiket Donasi telah ditambahkan.' },
  { name: 'ticket-role', description: 'Role spesifik yang di-ping / dapat melihat tiket saat baru terbuat.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-role [role]', exampleResponse: 'Role @SupportTeam berhasil diset sebagai penanggung jawab tiket.' },
  { name: 'ticket-logs', description: 'Menentukan tempat history / transkrip tiket disimpan.', category: 'Sistem Tiket Lanjutan', usage: '/ticket-logs [channel]', exampleResponse: 'Log tiket akan disimpan ke #transcript-logs.' },

  // --- Log & Audit Server ---
  { name: 'log-setup', description: 'Mengaktifkan sistem logging (pencatatan audit) lengkap.', category: 'Log & Audit Server', usage: '/log-setup [channel_target]', exampleResponse: 'Sistem logging aktif. Semua event direkam di #audit-logs.' },
  { name: 'log-message', description: 'Toggles pencatatan pesan diedit (Edit) & dihapus (Delete).', category: 'Log & Audit Server', usage: '/log-message [on/off]', exampleResponse: 'Pencatatan pesan edit & hapus telah dihidupkan.' },
  { name: 'log-member', description: 'Toggles pencatatan member keluar-masuk (Join/Leave).', category: 'Log & Audit Server', usage: '/log-member [on/off]', exampleResponse: 'Pencatatan member masuk/keluar dihidupkan.' },
  { name: 'log-moderation', description: 'Toggles pencatatan hukuman (Ban, Kick, Timeout, Warn).', category: 'Log & Audit Server', usage: '/log-moderation [on/off]', exampleResponse: 'Pencatatan log admin/moderasi aktif.' },
  { name: 'log-voice', description: 'Toggles pencatatan aktivitas Voice (Join, Move, Leave, Mute, Deafen).', category: 'Log & Audit Server', usage: '/log-voice [on/off]', exampleResponse: 'Pencatatan aktivitas suara (VC tracking) aktif.' },
  { name: 'log-role', description: 'Toggles pencatatan pembuatan/perubahan Role.', category: 'Log & Audit Server', usage: '/log-role [on/off]', exampleResponse: 'Pencatatan perubahan role telah aktif.' },
  { name: 'log-channel', description: 'Toggles pencatatan saat admin membuat/menghapus channel.', category: 'Log & Audit Server', usage: '/log-channel [on/off]', exampleResponse: 'Pencatatan aktivitas channel aktif.' },
  { name: 'audit-user', description: 'Lihat list aktivitas/tindakan moderasi terakhir untuk user tertentu.', category: 'Log & Audit Server', usage: '/audit-user [user]', exampleResponse: 'Daftar audit @spammer: 3x warns, 1x timeout.' },

  // --- Utilitas & Info Khusus Server ---
  { name: 'ping', description: 'Mengecek kecepatan respon dan latensi bot / gateway Discord.', category: 'Utilitas & Info', usage: '/ping', exampleResponse: '🏓 Pong! Latensi Bot: 42ms | Latensi API: 35ms' },
  { name: 'botinfo', description: 'Melihat rincian spesifikasi, memori, status host bot.', category: 'Utilitas & Info', usage: '/botinfo', exampleResponse: '🤖 **Bot v2.0-PRO** \n- RAM: 154MB / 1024MB \n- Uptime: 42 Hari' },
  { name: 'serverinfo', description: 'Mengecek detail profil, owner, region, boost tier dari server ini.', category: 'Utilitas & Info', usage: '/serverinfo', exampleResponse: '🏰 **Server Community** \n- Owner: Boss \n- Members: 5,420 \n- Boost: Lv 3' },
  { name: 'userinfo', description: 'Memeriksa detail umur pembuatan akun & tgl join server seseorang.', category: 'Utilitas & Info', usage: '/userinfo [user]', exampleResponse: '👤 **Profil kicaumania** \n- Umur Akun: 3 Tahun \n- Join: 22 Feb 2024' },
  { name: 'roleinfo', description: 'Melihat list permissions / jumlah anggota dari sebuah Role.', category: 'Utilitas & Info', usage: '/roleinfo [role]', exampleResponse: '🛡️ Role "Admin": Punya 18 anggota, Permissions lengkap.' },
  { name: 'avatar', description: 'Buka paksa dan unduh foto profil discord beresolusi tajam HD.', category: 'Utilitas & Info', usage: '/avatar [user]', exampleResponse: 'Berikut adalah tautan foto profil resolusi HD milik @budi.' },
  { name: 'banner', description: 'Mendownload foto banner profil seseorang (jika pakai Discord Nitro).', category: 'Utilitas & Info', usage: '/banner [user]', exampleResponse: 'Tautan banner resolusi HD untuk profil ini...' },
  { name: 'invite', description: 'Mendapat tautan resmi memasukkan/invite bot ini ke server lain.', category: 'Utilitas & Info', usage: '/invite', exampleResponse: 'Tautan undangan resmi bot: [Klik di Sini]' },
  { name: 'uptime', description: 'Mengukur seberapa lama bot menyala tanpa henti atau restart.', category: 'Utilitas & Info', usage: '/uptime', exampleResponse: 'Bot aktif selama: 32 Hari, 15 Jam, 42 Menit.' },
  { name: 'afk', description: 'Mode Away/Sibuk. Bot otomatis membalas sapaan ketika lo di tag teman.', category: 'Utilitas & Info', usage: '/afk [alasan]', exampleResponse: '💤 Anda afk: "Sedang Rapat", bot akan bales peringatan ke yang ngetag.' },
  { name: 'reminder', description: 'Memasang alarm pengingat waktu (bisa buat tugas/rapat).', category: 'Utilitas & Info', usage: '/reminder [waktu] [pesan]', exampleResponse: '⏳ Alarm aktif! Bot akan DM "Rapat Staf" dalam 5 jam.' },
  { name: 'shorten-url', description: 'Memperpendek link website / tugas panjang menggunakan s.id / url pendek.', category: 'Utilitas & Info', usage: '/shorten-url [url]', exampleResponse: 'Link pendek dirilis: https://s.id/pendek-banget' },

  // --- Musik & Voice ---
  { name: 'play', description: 'Memutar lagu atau menaruh link Spotify / Youtube / SoundCloud.', category: 'Musik & Voice', usage: '/play [judul/link]', exampleResponse: '🎵 Memutar: "Bernadya - Satu Bulan" di Voice.' },
  { name: 'skip', description: 'Loncat ke musik selanjutnya dalam antrean daftar putar server.', category: 'Musik & Voice', usage: '/skip', exampleResponse: '⏭️ Lagu saat ini dilompati! Memutar track antrean ke-2.' },
  { name: 'stop', description: 'Berhenti main musik sepenuhnya dan putuskan bot dari Voice Channel.', category: 'Musik & Voice', usage: '/stop', exampleResponse: '⏹️ Musik dimatikan & bot keluar mengaso.' },
  { name: 'queue', description: 'Sajikan list daftar antrian lagu yang disetel teman-teman di voice.', category: 'Musik & Voice', usage: '/queue', exampleResponse: '📜 Antrean Lagu: \n1. Payung Teduh \n2. Denny Caknan' },
  { name: 'volume', description: 'Menurunkan atau meninggikan tingkat desibel Volume bot musik (1-200%).', category: 'Musik & Voice', usage: '/volume [angka]', exampleResponse: '🔊 Volume dirubah jadi 80% tidak memekakkan telinga.' },
  { name: 'lyrics', description: 'Cari contekan lirik lagu secara realtime (terutama yg lg diputer).', category: 'Musik & Voice', usage: '/lyrics [judul]', exampleResponse: '🎤 Lirik "Satu Bulan": \n Sudah satu bulaaan berlaluuu...' },
  { name: 'bassboost', description: 'Efek musik bergemuruh / BassBoost DJ KTV untuk sensasi jedag jedug.', category: 'Musik & Voice', usage: '/bassboost [level]', exampleResponse: '🎧 Efek Jedag-Jedug Bass-Boost Level EXTREME aktif! 💥' },
  
  // --- Ekonomi Server Nusantara (Level & Uang Virtual) ---
  { name: 'level', description: 'Cek progress XP chatting / rank voice leveling anda di server.', category: 'Ekonomi Dasar & XP', usage: '/level', exampleResponse: '⭐ Rank: Lv. 15 (Super Sepuh) - 45k/50k XP.' },
  { name: 'leaderboard-level', description: 'List sepuluh anggota paling eksis, ngoceh mulu di server.', category: 'Ekonomi Dasar & XP', usage: '/leaderboard-level', exampleResponse: '🏆 Top Chatter: \n 1. @Admin (Lv. 99)' },
  { name: 'dompet', description: 'Lihat jumlah koin digital Rupiah yang ditabung di Bot.', category: 'Ekonomi Dasar & XP', usage: '/dompet', exampleResponse: '💳 **Dompet:** Rp 150.200 | 🏦 **Tabungan:** Rp 1.400.000' },
  { name: 'ngemis', description: 'Minta-minta koin gratis harian di pinggir jalan Discord.', category: 'Ekonomi Dasar & XP', usage: '/ngemis', exampleResponse: 'Anda mengemis dan mendapat Rp 15.000 dari bos dermawan.' },
  { name: 'kerja-banting-tulang', description: 'Kerja keras bagai quda. Dapat gaji random sesuai profesi lokal.', category: 'Ekonomi Dasar & XP', usage: '/kerja-banting-tulang', exampleResponse: 'Anda bekerja sebagai Tukang Parkir Indomaret dan digaji Rp 4.450!' },
  { name: 'transfer-pulsa', description: 'Mentransfer rupiah virtual ke sesama anggota sebagai hutang/uang jajan.', category: 'Ekonomi Dasar & XP', usage: '/transfer-pulsa [user] [jumlah]', exampleResponse: 'Sukses mengirimkan Rp 100.000 ke rekening @temanmu.' },
  { name: 'pasar-malam', description: 'Menampilkan katalog / etalase toko server tempat beli item & role eksklusif.', category: 'Ekonomi Dasar & XP', usage: '/pasar-malam', exampleResponse: '🎒 **Warung Bot:** \n1. Custom Role Sultan - Rp 1.000.000 \n2. Item "Batu Akik" - Rp 50.000' },
  { name: 'beli-role', description: 'Membeli role atau item dari /pasar-malam menggunakan rupiah.', category: 'Ekonomi Dasar & XP', usage: '/beli-role [nama_role]', exampleResponse: '🎉 Transaksi sukses! Anda sekarang menjadi Sultan.' },
  { name: 'inventory-warga', description: 'Melihat koleksi item lokal/nusantara yang anda beli di server.', category: 'Ekonomi Dasar & XP', usage: '/inventory-warga', exampleResponse: '🎒 Isi Tas: \n1x Keris Empu \n3x Es Cendol' },
  { name: 'gacha-kasta', description: 'Coba peruntungan duitmu untuk mendapatkan kasta tertinggi masyarakat.', category: 'Ekonomi Dasar & XP', usage: '/gacha-kasta', exampleResponse: '🎲 Wah! Rp50,000 hilang dan anda ampas: Tetap Jelata.' },
  { name: 'bayar-pajak', description: 'Sebagai warga taat, anda harus bayar pajak setiap minggu ke server.', category: 'Ekonomi Dasar & XP', usage: '/bayar-pajak', exampleResponse: 'Pajak Rp 10.000 berhasil ditarik bot dari dompetmu.' },
  { name: 'bansos', description: 'Gunakan saat server / member lagi krisis, ada random bansos koin.', category: 'Ekonomi Dasar & XP', usage: '/bansos', exampleResponse: 'Pemerintah server memberikan BLT Rp 25.000 untukmu!' },

  // --- Event & Perayaan (Nusantara) ---
  { name: 'gw-start', description: 'Memulai giveaway / bagi-bagi rezeki dengan countdown otomatis.', category: 'Giveaway & Event', usage: '/gw-start [durasi] [jumlah_pemenang] [hadiah]', exampleResponse: '🎉 Giveaway "Pulsa 50k" dimulai! Berakhir dalam 24 Jam.' },
  { name: 'gw-end', description: 'Menghentikan paksa giveaway yang sedang berjalan dan pilih pemenang.', category: 'Giveaway & Event', usage: '/gw-end [message_id]', exampleResponse: 'Giveaway dihentikan! Menghitung pemenang secara acak...' },
  { name: 'gw-reroll', description: 'Memilih ulang pemenang giveaway jika pemenang sebelumnya tidak sah.', category: 'Giveaway & Event', usage: '/gw-reroll [message_id]', exampleResponse: 'Mengocok ulang... Pemenang baru adalah @lucky_guy!' },
  { name: 'event-pasar', description: 'Membuka pasar malam dadakan. Belanja item diskon!', category: 'Giveaway & Event', usage: '/event-pasar [start/stop]', exampleResponse: 'Pasar malam di Townhall dibuka, silahkan borong item!' },
  { name: 'event-panjat-pinang', description: 'Bikin event mini game chat saling berebut hadiah pinang virtual.', category: 'Giveaway & Event', usage: '/event-panjat-pinang [hadiah]', exampleResponse: 'Tulis *PANJAT* secepatnya untuk dapat "Mie Instan"! Siapa cepat dia dapat!' },
  { name: 'event-tarik-tambang', description: 'Bagi 2 role menjadi tim, adu tarik tambang otomatis di channel.', category: 'Giveaway & Event', usage: '/event-tarik-tambang [role1] [role2]', exampleResponse: 'Role @TImA vs @TimB dimulai! Spam klik tombol TARIK!' },
  { name: 'event-mabar', description: 'Menjadwalkan Event Mabar dengan notifikasi pengingat otomatis.', category: 'Giveaway & Event', usage: '/event-mabar [nama_game] [waktu]', exampleResponse: 'Event "Mabar MLBB Malam" dijadwalkan pada jam 20:00 WIB.' },

  // --- Fun & Interaksi (Sosial) ---
  { name: 'marry', description: 'Menikahi member lain secara virtual dan ditampilkan di profile!', category: 'Fun & Interaksi', usage: '/marry [user]', exampleResponse: '💍 @joko melamar @siti! (Ketik yes/no untuk menerima).' },
  { name: 'divorce', description: 'Menceraikan pasangan virtual mu dengan dramatis.', category: 'Fun & Interaksi', usage: '/divorce', exampleResponse: '💔 @joko resmi bercerai.' },
  { name: 'hug', description: 'Memberikan pelukan hangat virtual menggunakan GIF anime lucu.', category: 'Fun & Interaksi', usage: '/hug [user]', exampleResponse: '🫂 @budi memberikan pelukan erat kepada @andi.' },
  { name: 'slap', description: 'Menampar teman yang rese secara virtual.', category: 'Fun & Interaksi', usage: '/slap [user]', exampleResponse: '🖐️ PLAK! @budi menampar wajah @spammer.' },
  { name: 'ship', description: 'Mengecek persentase kecocokan jodoh antara dua orang via AI bot.', category: 'Fun & Interaksi', usage: '/ship [user1] [user2]', exampleResponse: '❤️ Kecocokan Cinta = 85%! Mantap.' },

  // --- Automatisasi Ekstra ---
  { name: 'auto-reply', description: 'Membuat bot membalas otomatis kata kunci tertentu (Auto-Responder).', category: 'Otomasisasi Server', usage: '/auto-reply add [kata] [balasan]', exampleResponse: 'Trigger trigger ditambah: kalau ada yang ketik "p" bot bales "Salam".' },
  { name: 'rss-feed', description: 'Menerima update otomatis berita atau website menggunakan RSS link.', category: 'Otomasisasi Server', usage: '/rss-feed add [link_rss]', exampleResponse: 'RSS feed dihubungkan ke channel ini.' },
  { name: 'yt-alert', description: 'Memberikan notifikasi Video/Live Youtube ketika streamer favorit Live.', category: 'Otomasisasi Server', usage: '/yt-alert add [channel_yt]', exampleResponse: 'Notifikasi video baru Youtube diaktifkan!' },
  { name: 'sosmed-feed', description: 'Meneruskan twitter post dsb langsung ke Discord otomatis.', category: 'Otomasisasi Server', usage: '/sosmed-feed [username]', exampleResponse: 'Auto-post dipasang di channel #informasi.' },
  
  // --- Game Discord Seru ---
  { name: 'tictactoe', description: 'Main game silang bulat (Tic Tac Toe) melawan bot atau member lain dalam bentuk tombol discord.', category: 'Game Discord', usage: '/tictactoe [user]', exampleResponse: 'Game TicTacToe dimulai, giliran @budi X.' },
  { name: 'uno', description: 'Bermain game kartu UNO multiplayer santai memperebutkan koin server.', category: 'Game Discord', usage: '/uno start', exampleResponse: 'Lobby UNO dibuat! Menunggu partisipan lainnya...' },
  { name: 'tebak-lagu', description: 'Game tebak-tebak lagu dari audio pendek yang diputar di Voice Channel.', category: 'Game Discord', usage: '/tebak-lagu', exampleResponse: 'Memutar 10 detik intro lagu. Siapa cepat dia dapat!' },
  { name: 'truth-dare', description: 'Bermain game Truth or Dare (Jujur atau Tantangan) untuk memecah keheningan mabar.', category: 'Game Discord', usage: '/truth-dare', exampleResponse: 'Tantangan untuk @joko: Jangan kirim stiker selama 1 jam.' },
  { name: 'roulette', description: 'Roulette Rusia gaya komedi, user yang kalah akan di-mute 1 menit otomatis.', category: 'Game Discord', usage: '/roulette', exampleResponse: '🔫 *Klek* ... Dor! @ani tereliminasi (Mute 1 Menit).' },
  { name: 'hangman', description: 'Tebak kata klasik hangman, tebak huruf sampai nyawa (gambar gantung) habis.', category: 'Game Discord', usage: '/hangman', exampleResponse: 'Sistem kata: _ O _ K A T L_ ___. Tebak huruf!' },

  // --- Fitur Global & Super Penting Dunia ---
  { name: 'crypto-dunia', description: 'Pantau harga terkini mata uang kripto global (Bitcoin, Ethereum, Solana, dll) secara real-time.', category: 'Global & Ekonomi', usage: '/crypto-dunia [simbol]', exampleResponse: '📈 Info Crypto: Bitcoin (BTC) = $65,400 (+2.4%) dalam 24 Jam terakhir.' },
  { name: 'saham-global', description: 'Cek status saham perusahaan raksasa dunia (Apple, Google, Tesla, dll).', category: 'Global & Ekonomi', usage: '/saham-global [kode_saham]', exampleResponse: '📊 Saham AAPL (Apple Inc): $195.40 (+1.2%)' },
  { name: 'berita-dunia', description: 'Mendapatkan headline berita dunia paling terkini dan breaking news detik ini juga.', category: 'Global & Ekonomi', usage: '/berita-dunia [kategori]', exampleResponse: '📰 BREAKING: Peluncuran Roket SpaceX menuju Mars berhasil!' },
  { name: 'cuaca-global', description: 'Cek ramalan cuaca interaktif dengan satelit peta awan untuk seluruh kota di belahan dunia.', category: 'Global & Ekonomi', usage: '/cuaca-global [kota]', exampleResponse: '🌤️ Tokyo, JP: 24°C Cerah Berawan. Kelembapan: 60%' },
  { name: 'konversi-mata-uang', description: 'Kalkulator super cerdas yang menghitung konversi kurs mata uang fiat dunia terupdate.', category: 'Global & Ekonomi', usage: '/konversi-mata-uang [dari] [ke] [jumlah]', exampleResponse: '💱 Konversi: 100 USD (Dolar AS) = 1,650,000 IDR (Rupiah).' },
  { name: 'flight-tracker', description: 'Lacak langsung jadwal penerbangan pesawat internasional menggunakan radar global!', category: 'Global & Ekonomi', usage: '/flight-tracker [nomor_penerbangan]', exampleResponse: '✈️ Penerbangan GA-88: Sedang transit di Changi Airport (ETA: 2 Jam).' },
  { name: 'translate-dokumen', description: 'Upload file PDF/Word dan minta bot menerjemahkan isinya dalam hitungan detik!', category: 'Global & Ekonomi', usage: '/translate-dokumen [file]', exampleResponse: '📄 PDF sukses diterjemahkan ke Bahasa Indonesia: Terlampir.' },
  { name: 'detektor-hoax', description: 'Fact-checker sakti yang menggunakan database interpol dan media untuk mengecek apakah sebuah berita bohong.', category: 'Global & Ekonomi', usage: '/detektor-hoax [link_berita]', exampleResponse: '🚨 WARNING: Berita persentase Hoax 99%! (Sumber terbukti palsu).' },

  // --- Kearifan Lokal & Nusantara (Fitur Khas Indonesia) ---
  { name: 'jadwal-sholat', description: 'Menampilkan jadwal sholat 5 waktu akurat berdasarkan kota di Indonesia.', category: 'Kearifan Lokal & Nusantara', usage: '/jadwal-sholat [kota]', exampleResponse: 'Jadwal Sholat DKI Jakarta: Subuh 04:30, Dzuhur 11:55, Ashar 15:15... ' },
  { name: 'info-gempa', description: 'Menampilkan informasi gempa bumi terkini langsung dari data BMKG.', category: 'Kearifan Lokal & Nusantara', usage: '/info-gempa', exampleResponse: '🌍 Info BMKG: Gempa Magnitudo 5.2 di Barat Daya Bantul. Kedalaman 10km.' },
  { name: 'hari-libur', description: 'Cek daftar hari libur nasional (Tanggal Merah) di tahun ini.', category: 'Kearifan Lokal & Nusantara', usage: '/hari-libur', exampleResponse: '📅 Hari libur terdekat: 17 Agustus 2026 (Hari Kemerdekaan RI).' },
  { name: 'quotes-pahlawan', description: 'Motivasi harian dari kutipan para pahlawan kemerdekaan Indonesia.', category: 'Kearifan Lokal & Nusantara', usage: '/quotes-pahlawan', exampleResponse: '"Bangsa yang besar adalah bangsa yang menghormati jasa pahlawannya" - Ir. Soekarno.' },
  { name: 'kuliner-daerah', description: 'Cari resep atau sejarah makanan khas nusantara (Rendang, Gudeg, dll).', category: 'Kearifan Lokal & Nusantara', usage: '/kuliner-daerah [makanan]', exampleResponse: '🍲 Rendang: Masakan daging bercita rasa pedas dari Minangkabau. Diakui sebagai makanan terenak dunia.' },
  { name: 'sejarah-hari-ini', description: 'Menampilkan peristiwa bersejarah di Indonesia yang terjadi pada tanggal hari ini.', category: 'Kearifan Lokal & Nusantara', usage: '/sejarah-hari-ini', exampleResponse: '📜 Sejarah 10 November: Puncak pertempuran Surabaya (Hari Pahlawan Nasional).' },
  { name: 'tebak-daerah', description: 'Game tebak-tebakan provinsi di Indonesia berdasarkan ibu kota, budaya atau makanan khas.', category: 'Kearifan Lokal & Nusantara', usage: '/tebak-daerah', exampleResponse: 'Tebak! Provinsi manakah yang ibukotanya Semarang dan kulinernya Lumpia? ... (Jawa Tengah)' },

  // --- Alat Kreativitas Server ---
  { name: 'buat-meme', description: 'Pasang teks sakasme ke gambar template meme yang udah terkenal banget.', category: 'AI Canggih', usage: '/buat-meme [template] [teks_atas] [teks_bawah]', exampleResponse: 'Meme "Drake Hotline Bling" berhasil dibuat.' },
  { name: 'color', description: 'Hasilkan palet warna hex instan untuk desain role-role server aesthetic.', category: 'Utilitas & Info', usage: '/color [hex]', exampleResponse: 'Varian #9fe870: Lime Green, cocok dipasangkan dengan #2d4026.' },
  { name: 'ascii', description: 'Konversi kalimat biasa menjadi huruf-huruf gede gabungan karakter (ASCII ART).', category: 'Utilitas & Info', usage: '/ascii [teks]', exampleResponse: 'Teks "GANG INDO" di-generate jadi ASCII gede woy' },
  { name: 'reminder-list', description: 'Cek daftar / kalender reminder (alarm pengingat) yang sudah anda buat.', category: 'Utilitas & Info', usage: '/reminder-list', exampleResponse: 'Alarm Anda: "Angkat Sayur" (Jam 15:00).' },
  { name: 'avatar-server', description: 'Melihat tampilan spesifik foto profilenya di server ini aja (server avatar).', category: 'Utilitas & Info', usage: '/avatar-server [user]', exampleResponse: 'Avatar Server @warga lokal.' },
  { name: 'afk-list', description: 'Cek seluruh member admin atau mod yang statusnya lagi AFK Sibuk.', category: 'Manajemen Server', usage: '/afk-list', exampleResponse: 'Ada 2 admin sedang AFK: @A (Rebahan), @B (Kerja).' }
];
