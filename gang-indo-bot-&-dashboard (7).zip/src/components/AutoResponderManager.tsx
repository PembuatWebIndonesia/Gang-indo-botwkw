import React, { useState, useEffect } from 'react';
import { MessageSquare, Plus, Trash2, ShieldAlert, Cpu, Sparkles, Check, Zap } from 'lucide-react';

interface CustomCommand {
  id: string;
  trigger: string;
  response: string;
  fuzzyMatch: boolean;
  replyInDm: boolean;
}

interface CustomCommandsManagerProps {
  addLog: (type: 'info' | 'success' | 'warn' | 'error', source: 'Server' | 'Bot', message: string) => void;
}

export default function CustomCommandsManager({ addLog }: CustomCommandsManagerProps) {
  const [commands, setCommands] = useState<CustomCommand[]>(() => {
    const cached = localStorage.getItem('auto_responder_db');
    if (cached) {
      try { return JSON.parse(cached); } catch(e) {}
    }
    return [
      { id: 'cc_1', trigger: 'halo min', response: 'Halo warga! Sedang butuh bantuan? Silakan buka tiket di loket.', fuzzyMatch: true, replyInDm: false },
      { id: 'cc_2', trigger: '!rules', response: '1. Dilarang toxic agresif\n2. Dilarang spam link judi.\n3. Hormati Lurah dan Dewa Langit.', fuzzyMatch: false, replyInDm: false }
    ];
  });

  const [form, setForm] = useState({
    trigger: '',
    response: '',
    fuzzyMatch: true,
    replyInDm: false
  });

  useEffect(() => {
    localStorage.setItem('auto_responder_db', JSON.stringify(commands));
  }, [commands]);

  const handleAddCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.trigger.trim() || !form.response.trim()) return;

    const newCmd: CustomCommand = {
      id: 'cc_' + Math.random().toString(36).substring(2, 9),
      trigger: form.trigger.toLowerCase().trim(),
      response: form.response,
      fuzzyMatch: form.fuzzyMatch,
      replyInDm: form.replyInDm
    };

    setCommands([newCmd, ...commands]);
    addLog('success', 'Bot', `🤖 Auto-responder [${newCmd.trigger}] berhasil ditambahkan ke otak bot.`);
    setForm({ trigger: '', response: '', fuzzyMatch: true, replyInDm: false });
  };

  const handleDelete = (id: string) => {
    setCommands(commands.filter(c => c.id !== id));
    addLog('warn', 'Server', 'Konfigurasi auto-responder telah dihapus permanen.');
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-6 text-gray-100 overflow-y-auto animate-fade-in" id="custom-commands-panel">
      <div className="border-b border-[#2d4026] pb-5">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Cpu className="text-[#9fe870]" /> Otak Bot (Auto Responder & Custom Commands)
        </h2>
        <p className="text-sm text-gray-400 mt-1">
          Latih bot untuk secara otomatis menjawab kata kunci tertentu yang diketik warga di server Discord Anda.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-4 bg-[#141b11] border border-[#2d4026] p-6 rounded-2xl space-y-5 shadow-xl font-sans">
          <div className="flex items-center gap-2 border-b border-[#2d4026]/50 pb-3">
            <Sparkles size={16} className="text-[#9fe870]" />
            <h3 className="font-bold text-white">Latih Perintah Baru</h3>
          </div>

          <form onSubmit={handleAddCommand} className="space-y-4 text-sm text-zinc-300">
            <div className="space-y-1">
              <label className="text-xs uppercase font-semibold text-zinc-400">Pemicu / Kata Kunci Bot</label>
              <input
                type="text"
                required
                value={form.trigger}
                onChange={(e) => setForm({ ...form, trigger: e.target.value })}
                placeholder="Contoh: halo admin / !sosmed"
                className="w-full bg-black/40 border border-[#2d4026] px-3 py-2 rounded text-zinc-100 focus:border-[#9fe870] outline-none text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs uppercase font-semibold text-zinc-400">Teks Balasan Otomatis</label>
              <textarea
                required
                rows={4}
                value={form.response}
                onChange={(e) => setForm({ ...form, response: e.target.value })}
                placeholder="Ketikan balasan respon dari bot..."
                className="w-full bg-black/40 border border-[#2d4026] px-3 py-2 rounded text-zinc-100 focus:border-[#9fe870] outline-none text-xs leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-between bg-black/30 p-2.5 rounded border border-[#2d4026]">
              <label className="text-[11px] font-semibold text-zinc-400 cursor-pointer w-full" htmlFor="fuzzyToggle">
                Bisa Terdeteksi Ditengah Kalimat (Fuzzy Match)
              </label>
              <input 
                type="checkbox" 
                id="fuzzyToggle"
                checked={form.fuzzyMatch} 
                onChange={(e) => setForm({ ...form, fuzzyMatch: e.target.checked })} 
                className="accent-green-500 w-4 h-4"
              />
            </div>

            <div className="flex items-center justify-between bg-black/30 p-2.5 rounded border border-[#2d4026]">
              <label className="text-[11px] font-semibold text-zinc-400 cursor-pointer w-full" htmlFor="dmToggle">
                Balas Secara Private (Direct Message)
              </label>
              <input 
                type="checkbox" 
                id="dmToggle"
                checked={form.replyInDm} 
                onChange={(e) => setForm({ ...form, replyInDm: e.target.checked })} 
                className="accent-blue-500 w-4 h-4"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2 bg-gradient-to-r from-green-700 to-emerald-700 hover:from-green-600 hover:to-emerald-600 font-extrabold text-white text-xs rounded-lg uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
              >
                <Plus size={14} />
                Simpan Logika
              </button>
            </div>
          </form>
        </div>

        <div className="lg:col-span-8 flex flex-col gap-4">
          <div className="bg-yellow-900/10 border border-yellow-700/20 rounded-xl p-4 flex gap-3 text-xs text-yellow-500 font-sans">
            <ShieldAlert size={16} className="shrink-0 text-yellow-400" />
            <p className="leading-relaxed">
              Bot sudah berjalan dengan interval scan `messageCreate`. Jika pengguna mengirim pesan yang beririsan dengan *Pemicu*, bot akan langsung membalas sinkron dengan koneksi Discord WS Anda.
            </p>
          </div>

          <div className="bg-[#141b11] border border-[#2d4026] rounded-2xl overflow-hidden shadow-xl font-sans">
             <div className="p-4 bg-black/20 border-b border-[#2d4026] flex items-center justify-between">
                <h4 className="font-bold text-white text-sm">Library Logika Terpasang ({commands.length})</h4>
                <Zap size={14} className="text-[#9fe870]" />
             </div>
             <div className="p-4 space-y-3 max-h-[500px] overflow-y-auto">
                {commands.length === 0 ? (
                  <p className="text-center text-zinc-500 text-xs py-8 italic border border-dashed border-zinc-700 rounded-lg">Otak bot masih kosong. Latih dengan form di samping.</p>
                ) : (
                  commands.map((cmd) => (
                    <div key={cmd.id} className="p-4 bg-black/40 border border-zinc-800 rounded-xl flex flex-col gap-3 group relative hover:border-[#2d4026] transition-colors">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <span className="bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold">
                            IF PESAN = "{cmd.trigger}"
                          </span>
                          <span className="flex gap-2 text-[9px] font-mono mt-1 font-semibold">
                            {cmd.fuzzyMatch ? <span className="text-yellow-400">• Kalimat Bebas (Regex)</span> : <span className="text-blue-400">• Sama Persis (Exact)</span>}
                            {cmd.replyInDm && <span className="text-purple-400">• Balas Private (DM)</span>}
                          </span>
                        </div>
                        <button onClick={() => handleDelete(cmd.id)} className="text-zinc-600 hover:text-red-400 transition-colors p-1" title="Hapus memori">
                          <Trash2 size={15} />
                        </button>
                      </div>

                      <div className="bg-[#1e241c] p-3 rounded-lg border border-black text-xs text-zinc-300 font-sans break-all relative">
                        <MessageSquare size={12} className="absolute top-2 right-2 text-zinc-600" />
                        <span className="block text-[10px] text-zinc-500 uppercase font-mono mb-1">Bot Merespon:</span>
                        <p className="whitespace-pre-wrap leading-relaxed">{cmd.response}</p>
                      </div>
                    </div>
                  ))
                )}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
