import React, { useState } from 'react';
import { Gavel, Search, ShieldAlert, UserX, MessageSquareOff, UserMinus, History, CheckCircle2 } from 'lucide-react';
import { KtpRecord } from '../types';

interface ModerationManagerProps {
  citizens: KtpRecord[];
  addLog: (type: 'warn' | 'error' | 'success' | 'info', source: 'Server' | 'Bot', message: string) => void;
}

interface ModAction {
  id: string;
  targetId: string;
  targetUsername: string;
  actionParams: 'Warn' | 'Mute' | 'Kick' | 'Ban';
  reason: string;
  date: string;
}

export default function ModerationManager({ citizens, addLog }: ModerationManagerProps) {
  const [selectedUser, setSelectedUser] = useState('');
  const [reason, setReason] = useState('Melanggar aturan komunitas pasal 3');
  const [actionType, setActionType] = useState<'Warn' | 'Mute' | 'Kick' | 'Ban'>('Warn');
  
  const [modHistory, setModHistory] = useState<ModAction[]>(() => {
    const cached = localStorage.getItem('mod_history_db');
    if (cached) {
      try { return JSON.parse(cached); } catch(e) {}
    }
    return [
      { id: 'act_1', targetId: '1423851502016684712', targetUsername: 'kyle_3214', actionParams: 'Warn', reason: 'Spamming sticker berlebihan di general.', date: '11/06/2026' }
    ];
  });

  const handleExecuteAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      alert('Pilih target warga terlebih dahulu dari dropdown!');
      return;
    }

    const targetUser = citizens.find(c => c.username === selectedUser);
    if (!targetUser) return;

    const newAction: ModAction = {
      id: 'act_' + Math.random().toString(36).substring(2, 9),
      targetId: targetUser.userId,
      targetUsername: targetUser.username,
      actionParams: actionType,
      reason,
      date: new Date().toLocaleDateString('id-ID')
    };

    const nextHistory = [newAction, ...modHistory].slice(0, 50); // limit 50
    setModHistory(nextHistory);
    localStorage.setItem('mod_history_db', JSON.stringify(nextHistory));

    addLog('warn', 'Bot', `⚠️ EXECUTED [${actionType}] pada user @${targetUser.username}. Alasan: ${reason}`);
    
    // reset form
    setSelectedUser('');
    setReason('Melanggar aturan komunitas pasal 3');
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-6 text-gray-100 overflow-y-auto animate-fade-in" id="moderation-panel">
      <div className="border-b border-[#2d4026] pb-5">
        <h2 className="text-2xl font-bold text-red-500 flex items-center gap-2">
          <Gavel className="text-red-500" /> Pengadilan Server (Moderation Tools)
        </h2>
        <p className="text-sm text-gray-400 mt-1">
          Pusat eksekusi sanksi (Warn, Mute, Kick, Ban) beserta rekam jejak kriminal warga. Semuanya akan diumumkan secara live jika terhubung.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        {/* Left: Execution Form */}
        <div className="xl:col-span-5 bg-[#171313] border border-red-900/50 p-6 rounded-2xl shadow-2xl relative overflow-hidden font-sans">
          <div className="absolute -top-10 -right-10 text-red-900/20 z-0 rotate-12">
            <Gavel size={150} />
          </div>

          <div className="relative z-10 space-y-5">
            <div className="flex items-center gap-2 border-b border-red-900/40 pb-3">
               <ShieldAlert className="text-red-500" size={18} />
               <h3 className="font-bold text-red-100 text-base">Eksekusi Hukuman Baru</h3>
            </div>

            <form onSubmit={handleExecuteAction} className="space-y-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs uppercase font-extrabold text-red-400 tracking-wider">Pilih Tersangka (Username)</label>
                <select
                  required
                  value={selectedUser}
                  onChange={(e) => setSelectedUser(e.target.value)}
                  className="w-full bg-black/60 border border-red-900/40 px-3 py-2.5 rounded text-red-100 outline-none focus:border-red-500 text-xs font-mono"
                >
                  <option value="" disabled>-- Pilih dari database KTP --</option>
                  {citizens.map(c => (
                    <option key={c.id} value={c.username}>@{c.username} ({c.fullname})</option>
                  ))}
                  <option value="user_luar">@user_luar (Non-Warga)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs uppercase font-extrabold text-red-400 tracking-wider">Jenis Pidana Hukuman</label>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setActionType('Warn')}
                    className={`py-2 px-1 flex flex-col items-center justify-center rounded border transition-all ${
                      actionType === 'Warn' ? 'bg-yellow-600/30 border-yellow-500 text-yellow-300' : 'bg-black/40 border-zinc-800 text-zinc-500 hover:border-yellow-900'
                    }`}
                  >
                    <ShieldAlert size={16} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase">Warn</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActionType('Mute')}
                    className={`py-2 px-1 flex flex-col items-center justify-center rounded border transition-all ${
                      actionType === 'Mute' ? 'bg-orange-600/30 border-orange-500 text-orange-300' : 'bg-black/40 border-zinc-800 text-zinc-500 hover:border-orange-900'
                    }`}
                  >
                    <MessageSquareOff size={16} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase">Mute (TO)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActionType('Kick')}
                    className={`py-2 px-1 flex flex-col items-center justify-center rounded border transition-all ${
                      actionType === 'Kick' ? 'bg-red-600/30 border-red-500 text-red-300' : 'bg-black/40 border-zinc-800 text-zinc-500 hover:border-red-900'
                    }`}
                  >
                    <UserMinus size={16} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase">Kick</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActionType('Ban')}
                    className={`py-2 px-1 flex flex-col items-center justify-center rounded border transition-all shadow-[0_0_15px_rgba(255,0,0,0.1)] ${
                      actionType === 'Ban' ? 'bg-rose-900/40 border-rose-500 text-rose-300' : 'bg-black/40 border-zinc-800 text-zinc-500 hover:border-rose-900'
                    }`}
                  >
                    <UserX size={16} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase">Perma-Ban</span>
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs uppercase font-extrabold text-red-400 tracking-wider">Alasan (Log Public)</label>
                <textarea
                  required
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Ketik detail pelanggaran..."
                  className="w-full bg-black/60 border border-red-900/40 px-3 py-2 rounded text-zinc-200 focus:border-red-500 outline-none text-xs leading-relaxed"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-4 py-3 bg-red-700 hover:bg-red-600 text-white font-black text-xs rounded-xl uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(220,38,38,0.3)] transition-all active:scale-[0.98] flex items-center justify-center gap-2"
              >
                <Gavel size={16} /> JATUHKAN VONIS
              </button>
            </form>
          </div>
        </div>

        {/* Right: Moderation Audit Logs Ledger */}
        <div className="xl:col-span-7 bg-[#141b11] border border-[#2d4026] rounded-2xl overflow-hidden shadow-xl font-sans flex flex-col">
          <div className="p-4 bg-black/30 border-b border-[#2d4026] flex items-center justify-between">
             <div className="flex items-center gap-2">
                <History size={16} className="text-[#9fe870]" />
                <h4 className="font-bold text-white text-sm">Buku Rekam Jejak Pelanggaran (Audit Logs)</h4>
             </div>
             <span className="bg-red-950/50 text-red-400 border border-red-900/50 px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-widest flex items-center gap-1">
               <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse block"></span> Live Sync
             </span>
          </div>

          <div className="flex-1 p-4 space-y-3 overflow-y-auto max-h-[500px]">
            {modHistory.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-zinc-600 text-center border-2 border-dashed border-zinc-800 rounded-xl space-y-2">
                 <CheckCircle2 size={32} className="text-emerald-900" />
                 <p className="text-xs font-semibold text-zinc-500 uppercase tracking-widest font-mono">SERVER AMAN DAMAI</p>
                 <p className="text-[10px]">Belum ada pelanggaran hukum yang tercatat oleh bot.</p>
              </div>
            ) : (
              modHistory.map(log => {
                const colors = {
                  Warn: 'text-yellow-400 border-yellow-800/30 bg-yellow-950/10',
                  Mute: 'text-orange-400 border-orange-800/30 bg-orange-950/10',
                  Kick: 'text-rose-400 border-rose-800/30 bg-rose-950/10',
                  Ban: 'text-red-500 font-bold border-red-500/30 bg-red-950/30'
                };
                const colorTheme = colors[log.actionParams] || colors.Warn;

                return (
                  <div key={log.id} className={`p-4 rounded-xl border flex flex-col sm:flex-row gap-4 sm:items-center justify-between transition-all hover:brightness-125 ${colorTheme}`}>
                    <div className="space-y-1">
                      <div className="flex gap-2 items-center mb-2">
                        <span className="text-[10px] uppercase font-black tracking-widest font-mono bg-black/40 px-2 py-0.5 rounded shadow-sm border border-white/5">
                          {log.actionParams}
                        </span>
                        <span className="text-[10px] font-mono opacity-60 flex items-center justify-center gap-1">
                          <History size={10} /> {log.date}
                        </span>
                      </div>
                      <p className="text-white font-bold text-sm">Target: <span className="font-mono text-xs opacity-90">@{log.targetUsername}</span></p>
                      <p className="text-xs opacity-80 leading-relaxed font-sans italic">"{log.reason}"</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
