import React from 'react';
import { ShieldAlert, ShieldCheck, Link, Type, Image as LucideImage, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { usePersistentState } from '../hooks/usePersistentState';

export default function SecurityManager({ addLog }: { addLog: (type: 'warn' | 'error' | 'success' | 'info', source: 'Server' | 'Bot', message: string) => void }) {
  const [antiLink, setAntiLink] = usePersistentState('cfg_sec_link', true);
  const [antiSpam, setAntiSpam] = usePersistentState('cfg_sec_spam', true);
  const [antiNsfw, setAntiNsfw] = usePersistentState('cfg_sec_nsfw', false);
  const [antiCaps, setAntiCaps] = usePersistentState('cfg_sec_caps', false);
  const [antiRaid, setAntiRaid] = usePersistentState('cfg_sec_raid', false);

  const toggleToggle = (type: string, current: boolean, setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    setter(!current);
    addLog('success', 'Server', `Sistem ${type} telah di${!current ? 'aktifkan' : 'nonaktifkan'}.`);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-6 text-gray-100 overflow-y-auto animate-fade-in" id="security-panel">
      <div className="border-b border-[#2d4026] pb-5">
        <h2 className="text-2xl font-bold text-[#9fe870] flex items-center gap-2">
          <ShieldAlert className="text-[#9fe870]" /> Keamanan & Automod Server
        </h2>
        <p className="text-sm text-gray-400 mt-1">
          Lindungi server Discord Anda dari serangan raid, spam, pishing link, dan konten yang tidak pantas dengan filter otomatis cerdas.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Anti Link */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${antiLink ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <Link size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Anti-Link & Pishing</h3>
              <p className="text-xs text-gray-400">Blokir otomatis anggota biasa yang mengirimkan tautan / discord invite.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Anti-Link', antiLink, setAntiLink)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${antiLink ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

        {/* Anti Spam */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${antiSpam ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <AlertTriangle size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Filter Anti-Spam</h3>
              <p className="text-xs text-gray-400">Bisukan (mute) otomatis bagi member yang mengirim pesan terlalu cepat.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Anti-Spam', antiSpam, setAntiSpam)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${antiSpam ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

        {/* Anti NSFW */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${antiNsfw ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <LucideImage size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">AI Image Filter (NSFW)</h3>
              <p className="text-xs text-gray-400">Deteksi dan hapus otomatis gambar tidak senonoh menggunakan AI Bot.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Anti-NSFW', antiNsfw, setAntiNsfw)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${antiNsfw ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

        {/* Anti Raid */}
        <div className="bg-[#1e1010] border border-red-900/60 p-6 rounded-2xl flex items-center justify-between relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-red-950 to-transparent opacity-50 z-0"></div>
          <div className="flex items-center gap-4 relative z-10">
            <div className={`p-3 rounded-xl ${antiRaid ? 'bg-red-900/80 text-red-400' : 'bg-zinc-900 text-zinc-500'}`}>
              <ShieldCheck size={24} />
            </div>
            <div>
              <h3 className="font-bold text-red-400 mb-1">Darurat: Anti Raid Mode</h3>
              <p className="text-xs text-red-300/70">Kunci seluruh channel dari member baru. Aktifkan saat terkena bot attack.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Anti-Raid', antiRaid, setAntiRaid)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 relative z-10 ${antiRaid ? 'bg-red-500 justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-white w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

      </div>

    </div>
  );
}
