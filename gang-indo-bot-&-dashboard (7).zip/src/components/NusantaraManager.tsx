import React from 'react';
import { MapPin, BellRing, Settings2, Clock, Globe } from 'lucide-react';
import { usePersistentState } from '../hooks/usePersistentState';

export default function NusantaraManager({ addLog }: { addLog: (type: 'warn' | 'error' | 'success' | 'info', source: 'Server' | 'Bot', message: string) => void }) {
  const [region, setRegion] = usePersistentState('cfg_nus_region', 'Jakarta');
  const [sholatAlert, setSholatAlert] = usePersistentState('cfg_nus_sholat', true);
  const [gempaAlert, setGempaAlert] = usePersistentState('cfg_nus_gempa', true);
  const [autoQuote, setAutoQuote] = usePersistentState('cfg_nus_quote', true);

  const toggleToggle = (type: string, current: boolean, setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    setter(!current);
    addLog('success', 'Bot', `Fitur ${type} telah di${!current ? 'aktifkan' : 'nonaktifkan'}!`);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-6 text-gray-100 overflow-y-auto animate-fade-in" id="nusantara-panel">
      <div className="border-b border-[#2d4026] pb-5">
        <h2 className="text-2xl font-bold text-[#9fe870] flex items-center gap-2">
          <Globe className="text-[#9fe870]" /> Konfigurasi Kearifan Lokal
        </h2>
        <p className="text-sm text-gray-400 mt-1">
          Pengaturan khusus fitur-fitur Indonesia di server Anda: Broadcast azan otomatis, info BMKG, & konten budaya.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Wilayah / Region Setting */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl col-span-1 lg:col-span-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-green-900/40 text-[#9fe870]">
              <MapPin size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Zona Waktu & Kota Default Server</h3>
              <p className="text-xs text-gray-400">Digunakan untuk patokan jadwal alarm sholat, waktu server, dll.</p>
            </div>
          </div>
          <div className="w-full sm:w-auto mt-2 sm:mt-0">
             <select
                 value={region}
                 onChange={(e) => {
                     setRegion(e.target.value);
                     addLog('success', 'Server', `Zona pusat server diubah ke ${e.target.value}.`);
                 }}
                 className="w-full sm:w-64 bg-black/60 border border-[#2d4026] px-4 py-2.5 rounded-lg text-white font-semibold outline-none focus:border-[#9fe870]"
             >
                 <option value="Jakarta">DKI Jakarta (WIB)</option>
                 <option value="Bandung">Bandung, Jawa Barat (WIB)</option>
                 <option value="Surabaya">Surabaya, Jawa Timur (WIB)</option>
                 <option value="Yogyakarta">Yogyakarta (WIB)</option>
                 <option value="Denpasar">Denpasar, Bali (WITA)</option>
                 <option value="Makassar">Makassar, Sulawesi Selatan (WITA)</option>
                 <option value="Jayapura">Jayapura, Papua (WIT)</option>
             </select>
          </div>
        </div>

        {/* Sholat Alerts */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${sholatAlert ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <Clock size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Auto-Broadcast Azan</h3>
              <p className="text-xs text-gray-400">Bot mengirim notifikasi saat waktu sholat tiba di kota Anda.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Alarm Sholat', sholatAlert, setSholatAlert)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${sholatAlert ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

        {/* Info BMKG (Gempa) */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${gempaAlert ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <BellRing size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Push Notifikasi Gempa (BMKG)</h3>
              <p className="text-xs text-gray-400">Meneruskan laporan info gempa langsung dari portal BMKG ke server.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Notifikasi BMKG', gempaAlert, setGempaAlert)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${gempaAlert ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

        {/* Quotes Harian */}
        <div className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl flex items-center justify-between col-span-1 lg:col-span-2">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${autoQuote ? 'bg-green-900/40 text-[#9fe870]' : 'bg-zinc-900 text-zinc-500'}`}>
              <Settings2 size={24} />
            </div>
            <div>
              <h3 className="font-bold text-white mb-1">Daily Quotes Pahlawan</h3>
              <p className="text-xs text-gray-400">Mengirimkan kata mutiara dari pahlawan Indonesia secara otomatis setiap jam 8 pagi WIB.</p>
            </div>
          </div>
          <button 
            onClick={() => toggleToggle('Daily Quotes', autoQuote, setAutoQuote)}
            className={`w-14 items-center flex rounded-full p-1 transition-all duration-300 ${autoQuote ? 'bg-[#9fe870] justify-end' : 'bg-zinc-700 justify-start'}`}
          >
            <div className="bg-black w-5 h-5 rounded-full shadow-md"></div>
          </button>
        </div>

      </div>

    </div>
  );
}
