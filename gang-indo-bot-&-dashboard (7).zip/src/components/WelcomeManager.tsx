import React from 'react';
import { UserPlus, UserMinus, FileText, Send, CheckCircle2, Image as LucideImage } from 'lucide-react';
import { usePersistentState } from '../hooks/usePersistentState';

export default function WelcomeManager({ addLog }: { addLog: (type: 'warn' | 'error' | 'success' | 'info', source: 'Server' | 'Bot', message: string) => void }) {
  const [welcomeChannel, setWelcomeChannel] = usePersistentState('cfg_wel_channel', '');
  const [welcomeMessage, setWelcomeMessage] = usePersistentState('cfg_wel_msg', 'Selamat datang di server {server_name}, {user}! Jangan lupa baca rules.');
  
  const [leaveChannel, setLeaveChannel] = usePersistentState('cfg_leave_channel', '');
  const [leaveMessage, setLeaveMessage] = usePersistentState('cfg_leave_msg', 'Selamat jalan {user}, semoga tenang di sana.');

  const [autoRole, setAutoRole] = usePersistentState('cfg_auto_role', '');

  const handleSaveWelcome = (e: React.FormEvent) => {
    e.preventDefault();
    addLog('success', 'Bot', `Berhasil menyimpan konfigurasi sambutan member baru ke channel ${welcomeChannel || '#general'}.`);
  };

  return (
    <div className="flex-1 p-6 md:p-8 space-y-6 text-gray-100 overflow-y-auto animate-fade-in" id="welcome-panel">
      <div className="border-b border-[#2d4026] pb-5">
        <h2 className="text-2xl font-bold text-[#9fe870] flex items-center gap-2">
          <UserPlus className="text-[#9fe870]" /> Sistem Sambutan & Auto-Role
        </h2>
        <p className="text-sm text-gray-400 mt-1">
          Sambut warga baru agar merasa di rumah sendiri. Beri mereka role secara otomatis begitu masuk dan atur pesan perpisahan.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Welcome Config */}
        <form onSubmit={handleSaveWelcome} className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl space-y-5">
          <div className="flex items-center gap-2 border-b border-[#2d4026] pb-3">
            <UserPlus size={18} className="text-[#9fe870]" />
            <h3 className="font-bold">Konfigurasi Welcome</h3>
          </div>

          <div className="space-y-4 text-sm mt-4">
            <div>
              <label className="block text-xs uppercase font-bold text-gray-400 mb-1.5">Channel Sambutan</label>
              <select
                value={welcomeChannel}
                onChange={(e) => setWelcomeChannel(e.target.value)}
                className="w-full bg-black/60 border border-[#2d4026] px-3 py-2 rounded text-zinc-300 outline-none focus:border-[#9fe870]"
              >
                <option value="">-- Pilih Channel --</option>
                <option value="welcome">#welcome</option>
                <option value="general">#general</option>
                <option value="lobby">#lobby-utama</option>
              </select>
            </div>

            <div>
              <label className="block text-xs uppercase font-bold text-gray-400 mb-1.5 flex justify-between">
                <span>Pesan Sambutan</span>
                <span className="text-[9px] text-[#9fe870]">Variabel: {"{user}, {server_name}, {member_count}"}</span>
              </label>
              <textarea
                rows={3}
                value={welcomeMessage}
                onChange={(e) => setWelcomeMessage(e.target.value)}
                className="w-full bg-black/60 border border-[#2d4026] px-3 py-2 rounded text-zinc-300 outline-none focus:border-[#9fe870] resize-none"
              />
            </div>
          </div>
          
          <button type="submit" className="w-full flex justify-center items-center gap-2 bg-[#9fe870] hover:bg-[#8ade5e] text-black font-bold py-2 rounded-lg transition-colors text-sm">
            <Send size={16} /> Simpan Welcome
          </button>
        </form>

        {/* Leave Config & Autorole */}
        <div className="space-y-8">
          <form onSubmit={handleSaveWelcome} className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl space-y-5">
            <div className="flex items-center gap-2 border-b border-[#2d4026] pb-3">
              <UserMinus size={18} className="text-red-400" />
              <h3 className="font-bold">Konfigurasi Leave / Keluar</h3>
            </div>

            <div className="space-y-4 text-sm mt-4">
              <div>
                <label className="block text-xs uppercase font-bold text-gray-400 mb-1.5">Channel Perpisahan</label>
                <select
                  value={leaveChannel}
                  onChange={(e) => setLeaveChannel(e.target.value)}
                  className="w-full bg-black/60 border border-[#2d4026] px-3 py-2 rounded text-zinc-300 outline-none focus:border-[#9fe870]"
                >
                  <option value="">-- Pilih Channel --</option>
                  <option value="goodbye">#goodbye</option>
                  <option value="logs">#server-logs</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase font-bold text-gray-400 mb-1.5">Pesan Perpisahan</label>
                <textarea
                  rows={2}
                  value={leaveMessage}
                  onChange={(e) => setLeaveMessage(e.target.value)}
                  className="w-full bg-black/60 border border-[#2d4026] px-3 py-2 rounded text-zinc-300 outline-none focus:border-[#9fe870] resize-none"
                />
              </div>
            </div>
          </form>

          <form onSubmit={handleSaveWelcome} className="bg-[#121611] border border-[#2d4026]/60 p-6 rounded-2xl space-y-5 flex flex-col justify-between h-auto">
            <div className="flex flex-col sapce-y-2">
               <div className="flex items-center gap-2 border-b border-[#2d4026] pb-3 mb-4">
                 <FileText size={18} className="text-[#9fe870]" />
                 <h3 className="font-bold">Auto-Role Warga Baru</h3>
               </div>
               
               <div>
                  <label className="block text-xs uppercase font-bold text-gray-400 mb-1.5">Beri Pangkat Otomatis</label>
                  <select
                    value={autoRole}
                    onChange={(e) => setAutoRole(e.target.value)}
                    className="w-full bg-black/60 border border-[#2d4026] px-3 py-2 rounded text-zinc-300 outline-none focus:border-[#9fe870]"
                  >
                    <option value="">-- Tidak aktif --</option>
                    <option value="warga">@Warga Baru</option>
                    <option value="member">@Member Resmi</option>
                  </select>
                  <p className="text-[10px] text-gray-500 mt-2">Agar tidak dimanfaatkan bot spam, pastikan keamanan anti-raid menyala jika auto-role aktif.</p>
               </div>
            </div>
            
            <button type="submit" className="w-full flex justify-center items-center gap-2 mt-4 bg-zinc-800 hover:bg-zinc-700 border border-[#2d4026] text-white font-bold py-2 rounded-lg transition-colors text-sm">
              <CheckCircle2 size={16} className="text-[#9fe870]" /> Simpan Auto-Role
            </button>
          </form>
        </div>

      </div>

    </div>
  );
}
