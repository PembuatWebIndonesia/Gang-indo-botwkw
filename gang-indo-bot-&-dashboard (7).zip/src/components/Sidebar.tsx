import React from 'react';
import { LayoutDashboard, Bot, FolderHeart, Sparkles, Terminal, BookOpen, Settings, Info, Tag, Ticket, Music, Coins, FileCode, Gift, Gavel, ShieldAlert, ShieldCheck, UserPlus } from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  botStatus: 'ONLINE' | 'OFFLINE';
  botStats: { isReal: boolean, ping: number };
}

export default function Sidebar({ currentTab, setCurrentTab, botStatus, botStats }: SidebarProps) {
  const menuItems = [
    { id: 'overview', name: 'Ringkasan Bot', icon: LayoutDashboard },
    { id: 'config', name: 'Konfigurasi Bot', icon: Settings },
    { id: 'ktp', name: 'Arsip KTP Virtual', icon: FolderHeart },
    { id: 'gacha', name: 'Gacha Nasib', icon: Sparkles },
    { id: 'decorations', name: 'Hiasan Nickname', icon: Tag },
    { id: 'economy', name: 'Sistem Ekonomi XP', icon: Coins },
    { id: 'embed', name: 'Pembuat Embed', icon: FileCode },
    { id: 'giveaway', name: 'Undian & Giveaway', icon: Gift },
    { id: 'autoresponder', name: 'Auto Responder', icon: Terminal },
    { id: 'moderation', name: 'Alat Moderasi', icon: Gavel },
    { id: 'security', name: 'Keamanan & Automod', icon: ShieldCheck },
    { id: 'welcome', name: 'Sistem Sambutan', icon: UserPlus },
    { id: 'tickets', name: 'Tiket Bantuan', icon: Ticket },
    { id: 'music', name: 'Musik DJ Otomatis', icon: Music },
    { id: 'nusantara', name: 'Fitur Nusantara', icon: Sparkles },
    { id: 'commands', name: 'Daftar Perintah (110+)', icon: BookOpen },
  ];

  return (
    <aside className="w-full md:w-64 bg-[#141b11]/80 backdrop-blur-xl border-r border-[#2d4026]/70 text-gray-200 flex flex-col justify-between relative overflow-hidden" id="sidebar-container">
      {/* Decorative gradient blur in background */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#9fe870]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10">
        {/* Brand */}
        <div className="p-6 border-b border-[#2d4026]/70 flex flex-col space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 shadow-[0_0_15px_rgba(159,232,112,0.3)] bg-gradient-to-tr from-[#9fe870] to-green-500 rounded-lg text-black font-semibold">
              <Bot size={22} className="animate-pulse" />
            </div>
            <div>
              <h1 className="font-extrabold text-lg flex items-center gap-1.5 leading-tight text-white tracking-wide">
                Gang Indo
                <ShieldAlert size={14} className="text-[#9fe870]" />
              </h1>
              <span className="text-[9px] text-[#9fe870]/90 font-mono tracking-widest font-black uppercase">DISCORD BOT ENGINE</span>
            </div>
          </div>
        </div>

        {/* Live Status Guard */}
        <div className="mx-4 mt-6 mb-2 p-3 bg-gradient-to-br from-[#1a2517] to-[#121910] border border-[#2d4026]/80 rounded-xl shadow-lg relative overflow-hidden">
          <div className="absolute -right-2 -top-2 w-12 h-12 bg-[#9fe870]/10 rounded-full blur-xl pointer-events-none"></div>
          <div className="flex items-center justify-between relative z-10">
            <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400">Status Bot:</span>
            <div className="flex items-center space-x-2 bg-black/40 px-2 py-1 rounded-md border border-neutral-800">
              <span className={`h-2 w-2 rounded-full ${botStatus === 'ONLINE' ? 'bg-[#9fe870] shadow-[0_0_8px_#9fe870] animate-pulse' : 'bg-red-500'}`} />
              <span className={`text-[10px] font-black tracking-widest font-mono ${botStatus === 'ONLINE' ? 'text-[#9fe870]' : 'text-red-400'}`}>
                {botStatus}
              </span>
            </div>
          </div>
          <div className="mt-2.5 pt-2 border-t border-[#2d4026]/50 text-[9px] text-[#9fe870]/70 font-mono flex justify-between relative z-10">
            <span>{botStatus === 'ONLINE' ? 'TERKONEKSI' : 'TERPUTUS'}</span>
            <span>PING: {botStatus === 'ONLINE' && botStats.isReal ? botStats.ping + 'ms' : '—'}</span>
          </div>
        </div>

        {/* Menus */}
        <nav className="px-3 py-4 space-y-1 overflow-y-auto max-h-[calc(100vh-280px)] thin-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidemenu-tab-${item.id}`}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm transition-all duration-300 font-medium group relative overflow-hidden ${
                  isActive
                    ? 'bg-gradient-to-r from-[#293d22]/80 to-[#1b2a16] text-[#9fe870] border border-[#9fe870]/30 shadow-md font-semibold'
                    : 'text-gray-400 hover:bg-[#1a2517] hover:text-white border border-transparent'
                }`}
              >
                {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#9fe870]"></div>}
                <Icon size={18} className={`transition-all duration-300 ${isActive ? 'text-[#9fe870] drop-shadow-[0_0_5px_rgba(159,232,112,0.5)]' : 'text-gray-500 group-hover:text-gray-300'}`} />
                <span className="tracking-wide relative z-10">{item.name}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer credits inside sidebar */}
      <div className="p-5 border-t border-[#2d4026]/70 bg-gradient-to-t from-black/60 to-transparent text-center relative z-10">
        <p className="text-[10px] text-zinc-400 font-mono font-bold tracking-widest uppercase">Nexora Gang Indo</p>
        <p className="text-[9px] text-[#9fe870]/60 mt-1 uppercase tracking-widest font-bold">Premium OS v2.0</p>
      </div>
    </aside>
  );
}
