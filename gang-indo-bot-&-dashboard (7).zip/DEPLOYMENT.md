# 🚀 Panduan Deployment Gang Indo Bot & Dashboard (Node.js)

Dokumen ini menjelaskan cara men-deploy aplikasi kustom **Gang Indo Bot Dashboard** ke platform hosting yang mendukung **Node.js (Server Backend Terus-menerus)**. 

⚠️ **PENTING: KENAPA TIDAK BISA GITHUB PAGES / NETLIFY / VERCEL?**
Hosting seperti GitHub Pages, Netlify, dan Vercel dirancang untuk website **statis**. Bot Discord memerlukan koneksi **Websocket 24 Jam non-stop** untuk merespon perintah. Oleh karena itu, Anda WAJIB menggunakan hosting Node.js yang hidup terus menerus. Namun, Anda **tetap bisa menggunakan akun GitHub Anda** untuk login dan menyambungkan kode ke platform Node.js!

---

## 📦 Arsitektur Node.js

Aplikasi ini dibangun menggunakan arsitektur **Full-Stack Node.js (Vite + React + Express Node.js)**. Seluruh program (Dashboard & Bot Discord) telah dibungkus menjadi satu paket server siap jalan (`server.cjs`).
* **Perintah Build:** `npm run build`
* **Perintah Menjalankan:** `npm run start`

---

## 🛠️ Langkah-Langkah Deployment per Platform (Via Akun GitHub)

### 🟢 1. Koyeb (Solusi Terbaik & Gratis VDS)
Koyeb sangat mendukung Node.js 24/7 dan bisa langsung tarik kode dari GitHub Anda.
1. Kunjungi [Koyeb.com](https://www.koyeb.com/) dan login menggunakan akun **GitHub** Anda.
2. Klik tombol **Deploy** atau **Create App** dan pilih opsi **GitHub**. Pilih repositori bot Anda.
3. Koyeb akan memindai kode Anda dan otomatis mendeteksi konfigurasi.
4. Buka bagian **Environment Variables**, tambahkan:
   * `DISCORD_TOKEN` = Token Bot (opsional jika sudah diisi via panel web)
   * `DISCORD_CLIENT_ID` = Client ID Bot Discord
5. Pastikan konfigurasi Build & Run sudah benar:
   * **Build command:** `npm run build`
   * **Run command:** `npm run start`
6. Klik **Deploy**. Selesai! Dashboard web Anda akan punya domain gratis, dan Bot akan menyala siang malam.

### 🟣 2. Zeabur (Alternatif Paling Simpel)
Aplikasi Zeabur sangat pintar dan tidak butuh setting ribet.
1. Kunjungi [Zeabur.com](https://zeabur.com/) dan masuk menggunakan akun **GitHub**.
2. Klik **Create Project**, tambahkan layanan (**Add Service**) dari **Git**. Pilih repo Anda.
3. Zeabur akan otomatis menjalankan proses build `npm run build` tanpa perlu dikonfigurasi.
4. Tambahkan variabel (Env) jika perlu langsung di dashboard Zeabur.
5. Selesai! Layanan Anda kini online.

### 🔵 3. DigitalOcean App Platform / Heroku
Solusi industri berbayar standar jika Anda menginginkan stabilitas tinggi.
1. Login menggunakan akun GitHub.
2. Buat "New App" dan hubungkan ke repo Github proyek Anda.
3. Masukkan script build `npm run build` dan script start `npm run start`.
4. Bot langsung online dengan dashboard!

### 🖥️ 4. VPS Tradisional (Ubuntu / Debian / Centos)
Bagi tingkat lanjut yang memiliki server Cloud atau VPS pribadi.
1. Install Node.js v18+ dan git di server VPS Anda.
2. Clone repository github Anda ke dalam VPS:
   ```bash
   git clone <url-repository>
   cd <nama-folder>
   ```
3. Install semua dependensi Node.js:
   ```bash
   npm install
   ```
4. Jalankan kompilasi TypeScript & React:
   ```bash
   npm run build
   ```
5. Gunakan process manager seperti `pm2` agar server Node.js dan Bot Discord Anda tetap menyala 24/7 meskipun terminal SSH ditutup:
   ```bash
   npm install -g pm2
   pm2 start dist/server.cjs --name "gang-indo-bot"
   pm2 save
   ```
6. (Opsional) Setup reverse proxy menggunakan Nginx ke port `3000` untuk meng-online-kan dashboard panel admin web Anda.

---

## 💡 Konsep Manajemen Token
Kami tidak menggunakan database online di sini, semua token akan dikirim dengan aman secara otomatis menggunakan form autentikasi di halaman dashboard. Kode dari client akan di-proxy secara aman ke backend Express Node.js yang tersembunyi.
